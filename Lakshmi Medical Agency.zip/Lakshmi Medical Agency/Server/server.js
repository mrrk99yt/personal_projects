const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const multer = require('multer'); // File upload ke liye package

const app = express();
app.use(express.json());
app.use(cors());

// --- FOLDERS SETUP ---

// 1. 'uploads' folder ko public banao taaki browser image access kar sake
// Check karo folder hai ya nahi, nahi hai to bana do
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)){
    fs.mkdirSync(uploadDir);
}
app.use('/uploads', express.static(uploadDir));

// 2. Frontend Files (HTML/CSS/JS) serve karo (Jo parent folder me hain)
app.use(express.static(path.join(__dirname, '../')));


// --- DATABASE CONNECTION ---
mongoose.connect('mongodb://127.0.0.1:27017/lakshmiDB')
    .then(() => console.log("✅ Database Connected"))
    .catch(err => console.log("❌ Connection Error:", err));


// --- MODELS (Schema) ---
const User = mongoose.model('User', {
    ownerName: String,
    shopName: String,
    email: { type: String, unique: true },
    license: String,
    password: String,
    profilePic: { type: String, default: '' } // Photo ka naam yaha save hoga
});

const Inquiry = mongoose.model('Inquiry', {
    name: String,
    phone: String,
    shopName: String,
    message: String,
    date: { type: Date, default: Date.now }
});


// --- MULTER CONFIGURATION (Photo Save Karne ki Settings) ---
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, 'uploads/') // Photos 'uploads' folder me jayengi
    },
    filename: function (req, file, cb) {
        // File ka naam unique banane ke liye Date add kar rahe hain
        cb(null, Date.now() + '-' + file.originalname);
    }
});
const upload = multer({ storage: storage });


// --- API ROUTES ---

// 1. Home Page Route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../', 'index.html'));
});

// 2. Register API
app.post('/register', async (req, res) => {
    try {
        const newUser = new User(req.body);
        await newUser.save();
        res.json({ status: 'ok', message: 'Registration Successful!' });
    } catch (err) {
        res.json({ status: 'error', message: 'Email already exists or Error' });
    }
});

// 3. Login API
app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    const user = await User.findOne({ email, password });
    
    if (user) {
        res.json({ status: 'ok', user: user.ownerName });
    } else {
        res.json({ status: 'error', message: 'Wrong Email or Password' });
    }
});

// 4. Contact Form API
app.post('/contact', async (req, res) => {
    try {
        await new Inquiry(req.body).save();
        res.json({ status: 'ok', message: 'Message Sent Successfully!' });
    } catch (err) {
        res.json({ status: 'error', message: 'Failed to send message' });
    }
});

// 5. Get User Details (Profile Page ke liye)
app.post('/user-details', async (req, res) => {
    const { email } = req.body;
    try {
        const user = await User.findOne({ email: email });
        if (user) {
            // Agar photo hai, to uska pura URL bana kar bhejo
            const picUrl = user.profilePic ? `http://localhost:5000/uploads/${user.profilePic}` : null;
            
            // User data ke sath photo URL bhi bhejo
            res.json({ 
                status: 'ok', 
                user: { ...user._doc, profilePicUrl: picUrl } 
            });
        } else {
            res.json({ status: 'error', message: 'User not found' });
        }
    } catch (err) {
        res.json({ status: 'error', message: 'Server Error' });
    }
});

// 6. Update User Profile (Photo + Data)
// 'upload.single("photo")' photo receive karega
app.post('/update-user', upload.single('photo'), async (req, res) => {
    const { email, ownerName, shopName, license, password } = req.body;
    
    // Naya data taiyar karo
    let updateData = { ownerName, shopName, license, password };

    // Agar nayi photo aayi hai, to uska naam bhi update karo
    if (req.file) {
        updateData.profilePic = req.file.filename;
    }

    try {
        await User.findOneAndUpdate({ email: email }, updateData);
        res.json({ status: 'ok', message: 'Profile Updated Successfully!' });
    } catch (err) {
        console.error(err);
        res.json({ status: 'error', message: 'Update Failed' });
    }
});

// Server Start
app.listen(5000, () => console.log("🚀 Server running on http://localhost:5000"));